import org.junit.Test;

public class DemandTest {
    @Test
    public void test(){
        Main.main(new String[]{"-n","10000","-r","10"});
    }
}
